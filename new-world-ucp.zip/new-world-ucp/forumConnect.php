<?php

/*
	#     #
	##    #  ######  #    #  ######   ####   #    #   ####
	# #   #  #       ##  ##  #       #       #    #  #
	#  #  #  #####   # ## #  #####    ####   #    #   ####
	#   # #  #       #    #  #            #  #    #       #
	#    ##  #       #    #  #       #    #  #    #  #    #
	#     #  ######  #    #  ######   ####    ####    ####

 	______________________________________________________________________________________________

	Nemesus World Forumconnect v1.0 (WBB5)

	https://nemesus.de 
    
    	http://youtube.nemesus.de
	
	Discord: https://discord.nemesus.de

    	ToDo: Datei als forumConnect.php speichern

	ToDo: Zugriff nur auf eigene IP zulassen z.B durch eine Firewall
*/

error_reporting(E_ALL);

$id = $_GET["id"];
$status = $_GET["status"];

//ToDo: Sicherheitsschlüssel ändern
if ($id != "Mara261194?!?!" || empty($status)) return;

$betreff = $_GET["betreff"];
$nachricht = $_GET["nachricht"];
$userid = $_GET["userid"];
$name = $_GET["name"];
$groupids = $_GET["groupids"];
$zeit = $_GET["zeit"];
$grund = $_GET["grund"];
$theme = $_GET["theme"];
$email = $_GET["email"];
$trophyid = $_GET["trophyid"];

//ToDo: Link zur global.php anpassen
require('forum/global.php');

use wcf\util\UserUtil;
use wcf\data\user\UserAction;
use wcf\data\conversation\ConversationAction;
use wcf\data\user\User;
use wcf\data\user\trophy\UserTrophyAction;

$userObj = null;

if ($status == "conversation") {
    if (empty($betreff) || empty($nachricht) || empty($userid)) return;
    sendConversation($betreff, $nachricht, $userid);
    echo "1";
} else if ($status == "getid") {
    if (empty($name)) return;
    $id = getUserIDByUsername($name);
    echo "$id";
} else if ($status == "createthread") {
    if (empty($betreff) || empty($nachricht)) return;
    createThread($betreff, $nachricht);
    echo "1";
} else if ($status == "settogroups") {
    if (empty($userid) || empty($groupids)) return;
    $userObj = getUserByID($userid);
    $array = explode(",", $groupids);
    $action = new UserAction([$userObj], 'addToGroups', [
        'groups'  => $array,
        'addDefaultGroups' => false,
        'deleteOldGroups'  => false
    ]);
    if (!$action->executeAction()) {
        echo "0";
    }
    echo "1";
} else if ($status == "removefromgroups") {
    if (empty($userid) || empty($groupids)) return;
    $userObj = getUserByID($userid);
    $array = explode(",", $groupids);
    $action = new UserAction([$userObj], 'removeFromGroups', [
        'groups'  => $array
    ]);
    if (!$action->executeAction()) {
        echo "0";
    }
    echo "1";
} else if ($status == "updatename") {
    if (empty($userid) || empty($name)) return;
    $userObj = getUserByID($userid);
    $name = trim($name);
    if (UserUtil::isValidUsername($name) && UserUtil::isAvailableUsername($name)) {
        $action = new UserAction([$userObj], 'update', [
            'data' => array(
                'username' => $name
            )
        ]);
        $action->executeAction();
        echo "1";
    } else {
        echo "0";
    }
} else if ($status == "updatetheme") {
    if (empty($userid) || $theme < 0) return;
    $userObj = getUserByID($userid);
    $action = new UserAction([$userObj], 'update', [
        'data' => array(
            'styleID' => $theme
        )
    ]);
    $action->executeAction();
    echo "1";
} else if ($status == "ban") {
    if (empty($userid) || $zeit < 0 || empty($grund)) return;
    $userObj = getUserByID($userid);
    if ($zeit > 1) {
        $ban = date('d.m.Y H:i:s', time() + intval($zeit));
    } else {
        $ban = 0;
    }
    $action = new UserAction([$userObj], 'ban', [
        'banExpires' => $ban,
        'banReason'  => $grund
    ]);
    $action->executeAction();
    echo "1";
} else if ($status == "unban") {
    if (empty($userid)) return;
    $userObj = getUserByID($userid);
    if (!(new UserAction([$userObj], 'unban', []))->executeAction()) {
        echo "0";
    }
    echo "1";
} else if ($status == "password") {
    if (empty($email) || empty($userid)) return;
    $emailid = getUserIDByEmail($email);
    if ($userid == $emailid) {
        echo "1";
    } else {
        echo "0";
    }
} else if ($status == "trophy") {
    if (empty($userid) || empty($trophyid)) return;
    $userObj = getUserByID($userid);
    $action = new UserTrophyAction([], 'create', [
        'data' => [
            'trophyID'             => $trophyid,
            'userID'               => $userObj->userID,
            'description'          => '',
            'time'                 => TIME_NOW,
            'useCustomDescription' => 0
        ]
    ]);
    $action->executeAction();
    echo "1";
}

function getUserIDByUsername($username)
{
    $userObj = new User(null);
    $userObj = $userObj->getUserByUsername($username);
    $emailveri = $userObj->isEmailConfirmed();
    if (!$emailveri) {
        return -2;
    }
    if ($userObj->userID < 1) {
        return -1;
    }
    return $userObj->userID;
}

function getUserIDByEmail($email)
{
    $userObj = new User(null);
    $userObj = $userObj->getUserByEmail($email);
    $emailveri = $userObj->isEmailConfirmed();
    if (!$emailveri) {
        return -2;
    }
    if ($userObj->userID < 1) {
        return -1;
    }
    return $userObj->userID;
}

function getUserByID($id)
{
    $userObj = new User($id);
    $emailveri = $userObj->isEmailConfirmed();
    if (!$emailveri) {
        return -2;
    }
    if ($userObj->userID < 1) {
        return -1;
    }
    return $userObj;
}

function sendConversation($betreff, $nachricht, $userid)
{
    $conversationAction = new ConversationAction(array(), 'create', array(
        'data' => array(
            'subject' => $betreff,
            'time' => TIME_NOW,
            'userID' => 2, //ToDo: Bot userID anpassen
            'username' => 'Bot'
        ),
        'messageData' => array(
            'message' => $nachricht
        ),
        'participants' => array($userid)
    ));
    $conversationAction->executeAction();
}

function createThread($text1, $text2)
{
    $htmlInputProcessor = new \wcf\system\html\input\HtmlInputProcessor();
    $threadAction = new \wbb\data\thread\ThreadAction([], 'create', [
        'data' => array(
            'topic' => $text1,
            'boardID' => 8,
            'time' => TIME_NOW,
            'userID' => 2,
            'username' => 'Bot'
        ),
        'postData' => array(
            'message' => $text2
        ),
    ]);
    $threadAction->executeAction();
}