
  <footer class="main-footer">
      <div class="float-right d-none d-sm-inline">
          Created with ❤️ by <a href="https://nemesus.de">Nemesus.de</a>
      </div>
      <strong>Copyright &copy; 2023 <a href="https://nemesus.de" style="font-family: 'Exo', sans-serif;">Nemesus.de</a></strong> - All rights reserved | <a href="https://discord.nemesus.de">Discord</a> | <a href="https://yt.nemesus.de">Youtube</a> | <a href="https://ko-fi.com/nemesustv">Trinkgeld</a> | <a href="https://nemesus-world.de">Nemesus-World</a>
  </footer>
<?php /**PATH C:\Users\Administrator\Desktop\[Nemesus]\nemesus-world-ucp\resources\views/layouts/template-parts/footer.blade.php ENDPATH**/ ?>