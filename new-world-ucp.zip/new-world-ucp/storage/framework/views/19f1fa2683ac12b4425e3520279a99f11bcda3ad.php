<?php
use App\Http\Controllers\FunctionsController as FunctionsController;
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');
?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="box-header with-border">
            </div>
            <div class="card card-primary card-outline">
                <div class="card-header">Gruppierungen</div>
                <div class="card-body">
                    <?php echo $__env->make("layouts.template-parts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if(count($group)): ?>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                </div>
                                <input type="text" class="form-control" onkeyup="searchLog()" id="searchtext"
                                    name="searchtext" placeholder="Suche" maxlength="55">
                            </div>
                            <?php endif; ?>
                            <div class="card card-primary card-outline">
                                <div class="col-md-12">
                                    <?php if(count($group)): ?>
                                    <div class="table-responsive-md mt-2">
                                        <table id="logtable" class="table table-bordered" style="width:100%">
                                            <thead class="table-primary">
                                                <tr id="tablehead" class="tablehead">
                                                    <th>Name</th>
                                                    <th>Mitglieder</th>
                                                    <th>Status</th>
                                                    <th>Gründung</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><a style="color:rgba(255, 255, 255, 0.685)" href="/adminGroups/<?php echo e($data->id); ?>"><?php echo e($data->name); ?></a></td></td>
                                                    <td><?php echo e(FunctionsController::getGroupMembers($data->id)); ?></td>
                                                    <td><?php echo e(FunctionsController::getGroupStatus($data->status)); ?></td>
                                                    <td><?php echo e(strftime( '%d %b. %Y - %H:%M:%S',$data->created)); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php else: ?>
                                    <div class="text-center mt-1">
                                        <h3>Keine Gruppierungen gefunden!</h3>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
function searchLog() {
    const trs = document.querySelectorAll('#logtable tr:not(.tablehead)');
    const filter = document.querySelector('#searchtext').value;
    const regex = new RegExp(filter, 'i');
    const isFoundInTds = (td) => regex.test(td.innerHTML);
    const isFound = (childrenArr) => childrenArr.some(isFoundInTds);
    const setTrStyleDisplay = ({
        style,
        children
    }) => {
        style.display = isFound([...children]) ? '' : 'none';
    };
    trs.forEach(setTrStyleDisplay);
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\[Nemesus backup 31.07.2023]\nemesus-world-ucp\resources\views/layouts/admin/selectGroups.blade.php ENDPATH**/ ?>