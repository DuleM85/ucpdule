<?php
use App\Http\Controllers\FunctionsController as FunctionsController;
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');
?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="box-header with-border">
            </div>
            <div class="card card-primary card-outline">
                <div class="card-header">Items</div>
                <div class="card-body">
                    <?php echo $__env->make("layouts.template-parts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div style="display: flex; justify-content: center; align-items: center;">
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <!-- /.col -->
                            <div class="col-md-12">
                                <div class="card card-primary card-outline">
                                    <div class="col-md-12">
                                        <?php if(count($items)): ?>
                                        <label for="inputName" class="mt-3">Items</label>
                                        <div class="input-group mb-3 mt-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                            </div>
                                            <input type="text" class="form-control" onkeyup="searchLog()" id="searchtext"
                                                name="searchtext" placeholder="Suche" maxlength="55">
                                        </div>
                                        <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead class="table-primary">
                                                <tr>
                                                    <th>Item-ID</th>
                                                    <th>Besitzer</th>
                                                    <th>Identifizierer</th>
                                                    <th>Itemname</th>
                                                    <th>Menge</th>
                                                    <th>Gewicht</th>
                                                    <th>Position</th>
                                                    <th>Letztes Update</th>
                                                </tr>
                                            </thead>
                                            <tbody id="logtable">
                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->type != 5 && $data->type != 6): ?>
                                                <tr>
                                                    <td><?php echo e($data->itemid); ?></td>
                                                    <?php if($data->ownerid != -1): ?>
                                                        <td><?php echo e(FunctionsController::getCharacterName($data->ownerid)); ?></td>
                                                    <?php else: ?>
                                                        <td>Kein Besitzer</td>
                                                    <?php endif; ?>
                                                    <?php if(str_contains($data->owneridentifier,"evidence")): ?>
                                                    <td>Asservatenkammer</td>
                                                    <?php else: ?>
                                                        <td><?php echo e($data->owneridentifier); ?></td>
                                                    <?php endif; ?>
                                                    <td><?php echo e($data->description); ?> <?php if($data->props != "n/A" && strlen($data->props) > 5): ?><br/><span
                                                        class="badge badge-dark"><?php echo e($data->props); ?></span><?php endif; ?></td>
                                                    <td><?php echo e($data->amount); ?>x</td>
                                                    <td><?php echo e(FunctionsController::countItemWeight($data)); ?>g</td>
                                                    <?php if($data->posx): ?>
                                                    <td><?php echo e($data->posx); ?>, <?php echo e($data->posy); ?>, <?php echo e($data->posz); ?>, <?php echo e($data->dimension); ?></td>
                                                    <?php else: ?>
                                                    <td>Keine Position</td>
                                                    <?php endif; ?>
                                                    <td><?php echo e(strftime( '%d %b. %Y',$data->lastupdate)); ?></td>
                                                </tr>
                                                <?php else: ?>
                                                <tr style="color:lightblue">
                                                    <td><?php echo e($data->itemid); ?></td>
                                                    <?php if($data->ownerid != -1): ?>
                                                        <td><?php echo e(FunctionsController::getCharacterName($data->ownerid)); ?></td>
                                                    <?php else: ?>
                                                        <td>Kein Besitzer</td>
                                                    <?php endif; ?>
                                                    <?php if(str_contains($data->owneridentifier,"Furniture-")): ?>
                                                        <td>Furniture</td>
                                                    <?php else: ?>
                                                        <td><?php echo e($data->owneridentifier); ?></td>
                                                    <?php endif; ?>
                                                    <td><?php echo e($data->description); ?> <?php if($data->props != "n/A" && strlen($data->props) > 5): ?><br/><span
                                                        class="badge badge-dark"><?php echo e($data->props); ?></span><?php endif; ?></td>
                                                    <td><?php echo e($data->amount); ?>x</td>
                                                    <td><?php echo e($data->amount*$data->weight); ?>g</td>
                                                    <?php if($data->posx): ?>
                                                    <td><?php echo e($data->posx); ?>, <?php echo e($data->posy); ?>, <?php echo e($data->posz); ?>, <?php echo e($data->dimension); ?></td>
                                                    <?php else: ?>
                                                    <td>Keine Position</td>
                                                    <?php endif; ?>
                                                    <td><?php echo e(strftime( '%d %b. %Y',$data->lastupdate)); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        </div>
                                        <?php else: ?>
                                        <div class="text-center mt-1">
                                            <h3>Keine Items vorhanden!</h3>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
function searchLog()
{
    const trs = document.querySelectorAll('#logtable tr:not(.tablehead)');
    const filter = document.querySelector('#searchtext').value;
    const regex = new RegExp(filter, 'i');
    const isFoundInTds = (td) => regex.test(td.innerHTML);
    const isFound = (childrenArr) => childrenArr.some(isFoundInTds);
    const setTrStyleDisplay = ({ style, children }) => {
    style.display = isFound([...children]) ? '' : 'none';
  };
  trs.forEach(setTrStyleDisplay);
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\[Nemesus backup 31.07.2023]\nemesus-world-ucp\resources\views/layouts/admin/showitems.blade.php ENDPATH**/ ?>