<?php
use App\Http\Controllers\FunctionsController as FunctionsController;
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');
?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="box-header with-border">
            </div>
            <div class="card card-primary card-outline">
                <div class="card-header">Moje tikets</div>
                <div class="card-body">
                    <?php echo $__env->make("layouts.template-parts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if(count($mytickets)): ?>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                </div>
                                <input type="text" class="form-control" onkeyup="searchLog()" id="searchtext"
                                    name="searchtext" placeholder="Pretraga" maxlength="55">
                            </div>
                            <?php endif; ?>
                            <div class="card card-primary card-outline">
                                <div class="col-md-12">
                                    <div class="table-responsive-md mt-2">
                                        <?php if(count($mytickets)): ?>
                                        <table id="logtable" name="logtable" class="table table-bordered"
                                            style="width:100%">
                                            <thead class="table-primary">
                                                <tr id="tablehead" class="tablehead">
                                                    <th>ID</th>
                                                    <th>Naslov</th>
                                                    <th>Prioritet</th>
                                                    <th>Kreator</th>
                                                    <th>Urednik</th>
                                                    <th>Status</th>
                                                    <th>Datum izrade</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $mytickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($data->id); ?></td>
                                                    <td><a href="/showTicket/<?php echo e($data->id); ?>"
                                                            style="color:rgba(255, 255, 255, 0.685)"><?php echo e($data->title); ?></a>
                                                    </td>
                                                    <?php if($data->prio == 'low'): ?>
                                                    <td><span class="badge bg-primary ml-1">Nisko</span></td>
                                                    <?php elseif($data->prio == 'middle'): ?>
                                                    <td><span class="badge bg-warning ml-1">Srednje</span></td>
                                                    <?php else: ?>
                                                    <td><span class="badge bg-danger ml-1">Visoko</span></td>
                                                    <?php endif; ?>
                                                    <td><?php echo e(FunctionsController::getUserName($data->userid)); ?></td>
                                                    <td><?php echo e(FunctionsController::getUserNameTicket($data->admin)); ?></td>
                                                    <td><span
                                                            class="badge bg-primary"><?php echo e(FunctionsController::getTicketStatus($data->status)); ?></span>
                                                    </td>
                                                    <td><?php echo e(strftime( '%d %b. %Y - %H:%M:%S',$data->timestamp)); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php else: ?>
                                        <div class="text-center">
                                            <h3>Nema dostupnih tiketa!</h3>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    function searchLog() {
        const trs = document.querySelectorAll('#logtable tr:not(.tablehead)');
        const filter = document.querySelector('#searchtext').value;
        const regex = new RegExp(filter, 'i');
        const isFoundInTds = (td) => regex.test(td.innerHTML);
        const isFound = (childrenArr) => childrenArr.some(isFoundInTds);
        const setTrStyleDisplay = ({
            style,
            children
        }) => {
            style.display = isFound([...children]) ? '' : 'none';
        };
        trs.forEach(setTrStyleDisplay);
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\[Dule RageMP backup 13.09.2023]\new-world-ucp\resources\views/layouts/tickets/mytickets.blade.php ENDPATH**/ ?>