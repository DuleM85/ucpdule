<?php
    use App\Http\Controllers\FunctionsController as FunctionsController;
?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="card card-primary card-outline">
                <div class="card-header">Upit za pretragu</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $__env->make("layouts.template-parts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Pronadjene karaktere:</h3>
                                </div>
                                <div class="card-body p-0">
                                    <ul class="users-list clearfix">
                                        <?php if($characters): ?>
                                        <?php $__currentLoopData = $characters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if((FunctionsController::getDSGVOClosed($data->userid) == 0 && $data->closed == 0) || (Auth::user()->adminlevel > FunctionsController::High_Administrator && session('nemesusworlducp_adminlogin'))): ?>
                                        <li>
                                            <?php if(!empty($data->screen) && ($data->ucp_privat == 0 || (Auth::user()->adminlevel > FunctionsController::High_Administrator && session('nemesusworlducp_adminlogin')))): ?>
                                            <img src="<?php echo e($data->screen); ?>"
                                                style="max-weight: 15px;max-height: 176px;border-radius: 10%;border: 1px solid #adb5bd; width: 300px;" data-toggle="tooltip"
                                                data-placement="top" title="<?php echo e($data->name); ?>">
                                            <?php endif; ?>
                                            <?php if(Auth::user()->adminlevel > FunctionsController::Kein_Admin && session('nemesusworlducp_adminlogin')): ?>
                                            <a class="users-list-name"
                                                href="/search/showAdmin/<?php echo e($data->id+99); ?>"><?php echo e($data->name); ?></a>
                                            <?php else: ?>
                                            <a class="users-list-name"
                                                href="/search/show/<?php echo e($data->id+99); ?>"><?php echo e($data->name); ?></a>
                                            <?php endif; ?>
                                            <?php if($data->ucp_privat == 1): ?>
                                            <a class="users-list-name" href="#"><span
                                                    class="badge badge-danger">Privatno</span></a>
                                            <?php else: ?>
                                            <a class="users-list-name" href="#"><span
                                                    class="badge badge-primary">Javno</span></a>
                                            <?php endif; ?>
                                        </li>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <div class="col-md-12 mt-2 text-center">
                                            <h3 class="mt-2">Nisu pronađeni rezultati pretrage!</h3>
                                        </div>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\[Dule RageMP backup 13.09.2023]\new-world-ucp\resources\views/search.blade.php ENDPATH**/ ?>