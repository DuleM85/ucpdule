<?php
use App\Http\Controllers\HomeController as HomeController;
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');
?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="box-header with-border">
            </div>
            <div class="card card-primary card-outline">
                <div class="card-header">Statistika</div>
                <div class="card-body">
                    <?php echo $__env->make("layouts.template-parts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div style="display: flex; justify-content: center; align-items: center;">
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Opšta statistika</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Ime statistike</th>
                                                    <th>Statistika</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Nalozi kreirani</td>
                                                    <td><span class="badge bg-info"><?php echo e($accounts); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Kreirani karaktere</td>
                                                    <td><span class="badge bg-info"><?php echo e($charaktere); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Vozila</td>
                                                    <td><span class="badge bg-info"><?php echo e($cars); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Kuce</td>
                                                    <td><span class="badge bg-info"><?php echo e($houses); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Članovi tima</td>
                                                    <td><span class="badge bg-info"><?php echo e($team); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Vecina zločina</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Zločin</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $counter = 1
                                                ?>
                                                <?php $__currentLoopData = $crimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($counter ++); ?></td>
                                                    <td><?php echo e($data->name); ?></td>
                                                    <td><span class="badge bg-success">
                                                            <?php echo e($data->login_bonus); ?> Zločin</span></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Vecina sati igre</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Sati igranja</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $counter = 1
                                                ?>
                                                <?php $__currentLoopData = $play_time; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($counter ++); ?></td>
                                                    <td><?php echo e($data->name); ?></td>
                                                    <td><span class="badge bg-dark">Sati igranja:
                                                            <?php echo e($data->play_points); ?>h</span></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <?php if(count($shootingrange) > 0): ?>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Strelište</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Sekundi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $counter = 1
                                                ?>
                                                <?php $__currentLoopData = $shootingrange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($counter ++); ?></td>
                                                    <td><?php echo e($data->name); ?></td>
                                                    <td><span class="badge bg-dark">
                                                            <?php echo e($data->shootingrange); ?> Sekundi</span></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Najveci bonus za login</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Dana za redom</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $counter = 1
                                                ?>
                                                <?php $__currentLoopData = $login_bonus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($counter ++); ?></td>
                                                    <td><?php echo e($data->name); ?></td>
                                                    <td><span class="badge bg-danger">Loginbonus:
                                                            <?php echo e($data->login_bonus); ?> Tage</span></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Vecina smrtnih slučajeva</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Smrti</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $counter = 1
                                                ?>
                                                <?php $__currentLoopData = $tode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($counter ++); ?></td>
                                                    <td><?php echo e($data->name); ?></td>
                                                    <td><span class="badge bg-warning">Smrti: <?php echo e($data->deaths); ?></span>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Najviši level</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Level</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $counter = 1
                                                ?>
                                                <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($counter ++); ?></td>
                                                    <td><?php echo e($data->name); ?></td>
                                                    <td><span class="badge bg-primary">Level: <?php echo e($data->level); ?></span>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\[Dule RageMP backup 13.09.2023]\new-world-ucp\resources\views/getstatistic.blade.php ENDPATH**/ ?>