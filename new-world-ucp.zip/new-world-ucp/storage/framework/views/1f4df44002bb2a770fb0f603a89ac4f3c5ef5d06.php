<?php
use App\Http\Controllers\FunctionsController as FunctionsController;
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');
?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="card card-primary card-outline">
                <div class="card-header">Informacije o frakcijama</div>
                <div class="card-body">
                    <?php echo $__env->make("layouts.template-parts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Informacije o frakcijama</h3>
                                </div>
                                <div class="card-body box-profile">
                                    <h3 class="profile-username text-center">
                                        <?php echo e($faction->name); ?></h3>
                                    <p class="text-muted text-center">
                                        Osnovan u: <?php echo e(strftime( '%d %b. %Y - %H:%M:%S',$faction->created)); ?></p>
                                    <ul class="list-group list-group-bordered">
                                        <li class="list-group-item ">
                                            <b>Leitung</b> <a
                                                class="float-right"><?php echo e(FunctionsController::getCharacterName($faction->leader)); ?></a>
                                        </li>
                                        <li class="list-group-item ">
                                            <b>Aktuelle Mitglieder</b> <a class="float-right"><?php echo e($members); ?></a>
                                        </li>
                                        <li class="list-group-item ">
                                            <b>Mitglieder seid Gründung</b> <a
                                                class="float-right"><?php echo e($faction->members); ?></a>
                                        </li>
                                        <li class="list-group-item ">
                                            <b>Fahrzeuge</b> <a class="float-right"><?php echo e($cars); ?></a>
                                        </li>
                                        <li class="list-group-item ">
                                            <b>Kasseninhalt</b> <a class="float-right"><?php echo e($faction->bankvalue); ?>$</a>
                                        </li>
                                        <li class="list-group-item ">
                                            <b>Dienstzeit (Woche)</b> <a class="float-right"><?php echo e($dutytime); ?>h</a>
                                        </li>
                                        <li class="list-group-item ">
                                            <b>Fraktionslog</b> <a class="float-right"
                                                href="/setLog/faction-<?php echo e($faction->id); ?>">Einsehen</a>
                                        </li>
                                        <?php if($faction->id == 1): ?>
                                        <li class="list-group-item ">
                                            <b>Waffenkammerlog</b> <a class="float-right"
                                                href="/setLog/weapon-<?php echo e($faction->id); ?>">Einsehen</a>
                                        </li>
                                        <?php elseif($faction->id != 1 && $faction->id != 4): ?>
                                        <li class="list-group-item">
                                            <b>Lagerlog</b> <a class="float-right"
                                                href="/setLog/weapon-<?php echo e($faction->id); ?>">Einsehen</a>
                                        </li>
                                        <?php else: ?>
                                        <li class="list-group-item">
                                            <b>Staatskassenlog</b> <a class="float-right"
                                                href="/setLog/govmoney">Einsehen</a>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="table-responsive-md">
                                <table class="table table-bordered">
                                    <thead class="table-primary">
                                        <tr>
                                            <th>Name</th>
                                            <th>Mitglied seit</th>
                                            <th>Dienstzeit (Woche)</th>
                                            <th>Rang</th>
                                            <th>Verwaltung</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $characters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->name); ?>

                                                <?php if($data->online): ?> <span class="badge badge-success">Online</span></td>
                                            <?php else: ?>
                                            <span class="badge badge-danger">Offline</span> <?php if($data->swat == 1): ?><span
                                                class="badge badge-primary ml-1">SWAT</span><?php endif; ?></td>
                                            <?php endif; ?></td>
                                            </td>
                                            <td><?php echo e(strftime( '%d %b. %Y - %H:%M:%S',$data->faction_since)); ?></td>
                                            <td><span class="badge badge-info"><?php echo e($data->faction_dutytime); ?>h</span></td>
                                            <td><span
                                                    class="badge badge-primary"><?php echo e(FunctionsController::getRangName($data->rang,$data->faction)); ?>

                                                    (<?php echo e($data->rang); ?>)</span></td>
                                            <td>
                                                <div class="row">
                                                    <form class="ml-2" method="post"
                                                        action="<?php echo e(route('adminFactionKick')); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" class="form-control" id="factionid"
                                                            name="factionid" value="<?php echo e($faction->id); ?>" maxlength="11"
                                                            autocomplete="off">
                                                        <input type="hidden" name="id" id="id" value="<?php echo e($data->id); ?>"
                                                            autocomplete="off">
                                                        <button class="btn btn-info btn-sm" type="submit">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </form>
                                                    <form class="ml-1" method="post"
                                                        action="<?php echo e(route('adminFactionLeader')); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" class="form-control" id="factionid"
                                                            name="factionid" value="<?php echo e($faction->id); ?>" maxlength="11"
                                                            autocomplete="off">
                                                        <input type="hidden" name="id" id="id" value="<?php echo e($data->id); ?>"
                                                            autocomplete="off">
                                                        <button class="btn btn-info btn-sm" type="submit">
                                                            <i class="fas fa-user-tie"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\[Nemesus backup 31.07.2023]\nemesus-world-ucp\resources\views/layouts/admin/adminFactions.blade.php ENDPATH**/ ?>