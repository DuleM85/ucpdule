@php
use App\Http\Controllers\HomeController as HomeController;
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');
@endphp
@extends('layouts.master')
@section('content')
<head>
    <link rel="stylesheet" href="{{asset('adminlte/plugins/daterangepicker/daterangepicker.css')}}">
</head>
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="box-header with-border">
            </div>
            <div class="card card-primary card-outline">
                <div class="card-header">Prijava neaktivnost</div>
                <div class="card-body">
                    <div style="display: flex; justify-content: center; align-items: center;">
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <!-- /.col -->
                            <div class="col-md-12">
                                @include("layouts.template-parts.alert")
                                <div class="card card-primary card-outline">
                                    <div class="col-md-12">
                                        <div class="col-md-12">
                                            <div style="display: flex; justify-content: center; align-items: center;">
                                                <img src="/images/urlaub.png" class="mt-2" width="90%"
                                                    style="max-width: 100px;max-height: 95px" />
                                            </div>
                                            @if(count($inaktiv) == 0)
                                            <div style="display: flex; justify-content: center; align-items: center;">
                                                <h6 class="mt-3 text-center">Informacije: Ovde možete prijaviti da ste
                                                    neaktivni da ne biste
                                                    izgubili ograničene resurse u igri kao što su kuće. Ako ne želite da navedete
                                                    razlog, možete takođe pisati <strong>privatno</strong>.</h6>
                                            </div>
                                            <div style="display: flex; justify-content: center; align-items: center;">
                                                <h6 class="mt-3 text-center">Drugi igrači mogu da vide vaš
                                                    izveštaj o
                                                    neaktivnosti, ako je vaš UCP profil podešen na <strong>javno</strong>
                                                    kada se prijavite na server igre, izveštaj o neaktivnosti ce se
                                                    automatski izbrisati!</h6>
                                            </div>
                                            <div style="display: flex; justify-content: center; align-items: center;">
                                                <form class="form-horizontal" method="POST"
                                                    action="{{ route('setInaktiv') }}">
                                                    @csrf
                                                    <label class="mt-4">Razlog</label>
                                            </div>
                                            <div style="display: flex; justify-content: center; align-items: center;">
                                                <input class="form-control text-center" placeholder="npr. Godisnji odmor"
                                                    type="text" name="grund" id="grund" maxlength="35"
                                                    autocomplete="off">
                                            </div>
                                        </div>
                                        <div style="display: flex; justify-content: center; align-items: center;">
                                            <label class="mt-2">Razdoblje</label><br />
                                        </div>
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input class="form-control text-center" name="daterange" type="text"
                                                    maxlength="23" id="daterange" autocomplete="off">
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-block btn-primary mb-2 mt-3">Pošalji prijavu neaktivnost</button>
                                        </form>
                                        @else
                                        @foreach($inaktiv as $data )
                                        <div style="display: flex; justify-content: center; align-items: center;">
                                            <h6 class="mt-3">Info: Još uvek ste od <strong
                                                    style="color:green">{{strftime( '%d %b. %Y',$data->date1)}}</strong>
                                                    sve do
                                                <strong
                                                    style="color:green">{{strftime( '%d %b. %Y',$data->date2)}}</strong>
                                                    prijavljen
                                                    kao neaktivan, koristite dugme ispod da biste otkazali izveštaj o
                                                    neaktivnosti!
                                            </h6>
                                        </div>
                                        <form class="form-horizontal" method="POST"
                                            action="{{ route('unsetInaktiv') }}">
                                            @csrf
                                            <button type="submit"
                                                class="btn btn-block btn-primary mb-2 mt-3">Obrišite obaveštenje o
                                                neaktivnosti</button>
                                        </form>
                                        @endforeach
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('scripts')
<script src="{{asset('adminlte/plugins/moment/moment.min.js')}}"></script>
<script src="{{asset('adminlte/plugins/daterangepicker/daterangepicker.js')}}"></script>
<script>
var date1 = moment();
var date2 = moment().add('days', 14);
$('input[name="daterange"]').daterangepicker({
    startDate: moment(),
    endDate: moment().add('days', 14),
    minDate: moment(),
    maxDate: moment().add('months', 6),
    showDropdowns: true,
    showWeekNumbers: true,
    timePicker: false,
    timePickerIncrement: 1,
    timePicker12Hour: false,
    ranges: {
        'Danas': [moment(), moment()],
        'Jučer': [moment().subtract('days', 1), moment().subtract('days', 1)],
        'Poslednjih 7 dana': [moment().subtract('days', 6), moment()],
        'Poslednjih 30 dana': [moment().subtract('days', 29), moment()],
        'Ovog meseca': [moment().startOf('month'), moment().endOf('month')],
        'Prošlog meseca': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1)
        .endOf('month')]
        },
        opens: 'left',
        format: 'DD.MM.YYYY',
        separator: ' to ',
        locale: {
        format: 'DD.MM.YYYY',
        applyLabel: 'Potvrdi',
        cancelLabel: 'Poništiti',
        fromLabel: 'Od',
        toLabel: 'Do',
        customRangeLabel: 'Prilagođeno',
        daysOfWeek: ['Ned', 'Pon', 'Uto', 'Sre', 'Čet', 'Pet', 'Sub'],
        monthNames: ['Januar', 'Februar', 'Mart', 'April', 'Maj', 'Jun', 'Jul', 'Avgust', 'Septembar', 'Oktobar', 'Novembar', 'Decembar'],
        firstDay: 1
        },
    },
    function (start, end) {
        date1 = start;
        date2 = end;
        console.log(start.format('DD.MM.YYYY'));
    }
);
function postInactiv() {
    window.location.href = "{{URL::to('setInactiv')}}" + "/" + date1 + "/" + date2;
}
</script>
@endpush
