
  <footer class="main-footer">
      <div class="float-right d-none d-sm-inline">
            Kreirao sa ❤️ - <a href="https://nw-rp.com">DuleM85</a>
      </div>
      <strong>Copyright &copy; Sept 2023 <a href="https://balkanrp.com" style="font-family: 'Exo', sans-serif;">balkanrp.com</a></strong> - Sva prava zadržana | <a href="https://discord.gg/ndJaDVh5q5">Discord</a> | <a href="https://www.youtube.com/@balkannewworldroleplay9726/featured">Youtube</a> | <a href="https://paypal.me/BalkanNWRP?country.x=AT&locale.x=de_DE">Donacije</a> | <a href="https://www.tiktok.com/@balkannwrp">Tik-Tok</a>
  </footer>
