@extends('layouts.master')
@section('content')
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="box-header with-border">
            </div>
            <div class="card card-primary card-outline">
                <div class="card-header">
                    Verifikacija naloga na forumu</div>
                <div class="card-body">
                    @include("layouts.template-parts.alert")
                    <div class="row">
                        <div class="col-md-12 text-center">
                            @if (Auth::user()->forumaccount == -1)
                            <div style="display: flex; justify-content: center; align-items: center;">
                                Da bi vaša prava bila automatski ažurirana i, na primer, da bi vam bila
                                dodeljena prava frakcije ili da biste mogli da pišete na forumu, potrebna
                                vam je veza sa našim serverom za igre. Kliknite na dugme ispod da
                                potvrdite svoj nalog na forumu!
                            </div>
                            @if ($forumcheck != -1)
                            <br />
                            <div style="display: flex; justify-content: center; align-items: center;">
                                Pronađen nalog na forumu: &nbsp; <strong>{{Auth::user()->name}}
                                    ({{$forumcheck}})</strong>
                            </div>
                            <form class="form-horizontal text-center" method="POST" action="{{ route('postForum') }}">
                                @csrf
                                <button type="submit" class="btn btn-primary mt-4">Povežite nalog na forumu</button>
                            </form>
                            @else
                            <br />
                            <div style="display: flex; justify-content: center; align-items: center;">
                                <h4 style="color: red">Nije moguce pronaci nalog na forumu, otvorite
                                    ga ili promenite svoje ime
                                    na forumu!</h4>
                            </div>
                            @endif
                        </div>
                        </form>
                        @elseif (Auth::user()->forumaccount == -2)
                        <div style="display: flex; justify-content: center; align-items: center;">
                            Poslali ste razgovor na forumu sa kodom, unesite ovaj kod
                            ispod:
                        </div>
                        <br />
                        <form class="form-horizontal text-center" method="POST" action="{{ route('postForum') }}">
                            @csrf
                            <input class="form-control text-center" placeholder="Kod" type="text" name="code" id="code"
                                maxlength="4" autocomplete="off">
                            <button type="submit" class="btn btn-primary mt-4">Weiter</button>
                        </form>
                        @else
                        <form class="form-horizontal text-center" method="POST" action="{{ route('updateForum') }}">
                            @csrf
                            <div style="display: flex; justify-content: center; align-items: center;">
                                Uspešno ste povezali svoj nalog na forumu, vaša prava će sada biti
                                automatski
                                sinhronizovana! Ako želite da otkažete
                                verifikaciju, kontaktirajte
                                administratora!
                            </div>
                            <div style="display: flex; justify-content: center; align-items: center;">
                                <button type="submit" class="btn btn-primary mt-4">Ažurirajte prava na forumu</button>
                            </div>
                        </form>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
