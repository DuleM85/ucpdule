@extends('layouts.master')
@section('content')
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="card card-primary card-outline">
                <div class="card-header">
                Dvofaktorska autentifikacija</div>
                <div class="card-body">
                    @include("layouts.template-parts.alert")
                    <div class="row">
                        <div class="col-md-12 text-center">
                            @if (Auth::user()->google2fa_secret == null)
                            <div style="display: flex; justify-content: center; align-items: center;">
                                Aktivirajte dvofaktorsku autentifikaciju za UCP i server igre skeniranjem QR-kod
                                ispod. Alternativno, možete koristiti i ovaj kod: &nbsp;
                                <strong>{{ $secret }}</strong>
                            </div>
                            <div style="display: flex; justify-content: center; align-items: center;">
                                Koristite aplikaciju za potvrdu identiteta na svom Smartphone kao što je &nbsp; <a
                                    href="https://support.google.com/accounts/answer/1066447?hl=sr&co=GENIE.Platform%3DAndroid">Google
                                    Authenticator</a>, redovno pravite rezervne kopije aplikacije, bez
                                    toga možete vi &nbsp;<strong>više ne</strong>&nbsp; prijaviti!
                            </div>
                            <div class="mt-3" style="display: flex; justify-content: center; align-items: center;">
                                {!! $QR_Image !!}
                            </div>
                            <form class="form-horizontal text-center" method="POST"
                                action="{{ route('postTwoFactor') }}">
                                @csrf
                                <input id="one_time_password" name="one_time_password" type="hidden"
                                    class="form-control mt-4 text-center" value="{{ $secret }}" maxlength="6"
                                    name="one_time_password" autocomplete="off">
                                <button type="submit" class="btn btn-primary mt-4">Skenirao sam
                                    QR-Kod!</button>
                            </form>
                        </div>
                        </form>
                        @else
                        <form class="form-horizontal text-center" method="POST"
                            action="{{ route('postDeleteTwoFactor') }}">
                            @csrf
                            Aktivirali ste dvofaktornu autentifikaciju i možete je deaktivirati u nastavku, imajte
                            na umu da ce to smanjiti sigurnost vašeg naloga!</strong>
                            <div class="mt-3" style="display: flex; justify-content: center; align-items: center;">
                                <button type="submit" class="btn btn-danger mt-4">Deaktivirajte dvofaktorsku
                                autentifikaciju</button>
                            </div>
                    </div>
                    </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
@endsection
