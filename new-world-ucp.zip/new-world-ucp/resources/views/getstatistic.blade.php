@php
use App\Http\Controllers\HomeController as HomeController;
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');
@endphp
@extends('layouts.master')
@section('content')
<div class="row justify-content-center">
    <div class="col-md-12 mt-1">
        <div class="box box-default">
            <div class="box-header with-border">
            </div>
            <div class="card card-primary card-outline">
                <div class="card-header">Statistika</div>
                <div class="card-body">
                    @include("layouts.template-parts.alert")
                    <div style="display: flex; justify-content: center; align-items: center;">
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Opšta statistika</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Ime statistike</th>
                                                    <th>Statistika</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Nalozi kreirani</td>
                                                    <td><span class="badge bg-info">{{$accounts}}</td>
                                                </tr>
                                                <tr>
                                                    <td>Kreirani karaktere</td>
                                                    <td><span class="badge bg-info">{{$charaktere}}</td>
                                                </tr>
                                                <tr>
                                                    <td>Vozila</td>
                                                    <td><span class="badge bg-info">{{$cars}}</td>
                                                </tr>
                                                <tr>
                                                    <td>Kuce</td>
                                                    <td><span class="badge bg-info">{{$houses}}</td>
                                                </tr>
                                                <tr>
                                                    <td>Članovi tima</td>
                                                    <td><span class="badge bg-info">{{$team}}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Vecina zločina</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Zločin</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                $counter = 1
                                                @endphp
                                                @foreach ($crimes as $data)
                                                <tr>
                                                    <td>{{$counter ++}}</td>
                                                    <td>{{$data->name}}</td>
                                                    <td><span class="badge bg-success">
                                                            {{$data->login_bonus}} Zločin</span></td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Vecina sati igre</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Sati igranja</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                $counter = 1
                                                @endphp
                                                @foreach ($play_time as $data)
                                                <tr>
                                                    <td>{{$counter ++}}</td>
                                                    <td>{{$data->name}}</td>
                                                    <td><span class="badge bg-dark">Sati igranja:
                                                            {{$data->play_points}}h</span></td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            @if (count($shootingrange) > 0)
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Strelište</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Sekundi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                $counter = 1
                                                @endphp
                                                @foreach ($shootingrange as $data)
                                                <tr>
                                                    <td>{{$counter ++}}</td>
                                                    <td>{{$data->name}}</td>
                                                    <td><span class="badge bg-dark">
                                                            {{$data->shootingrange}} Sekundi</span></td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            @endif
                        </div>
                        <div class="col-md-6">
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Najveci bonus za login</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Dana za redom</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                $counter = 1
                                                @endphp
                                                @foreach ($login_bonus as $data)
                                                <tr>
                                                    <td>{{$counter ++}}</td>
                                                    <td>{{$data->name}}</td>
                                                    <td><span class="badge bg-danger">Loginbonus:
                                                            {{$data->login_bonus}} Tage</span></td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Vecina smrtnih slučajeva</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Smrti</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                $counter = 1
                                                @endphp
                                                @foreach ($tode as $data)
                                                <tr>
                                                    <td>{{$counter ++}}</td>
                                                    <td>{{$data->name}}</td>
                                                    <td><span class="badge bg-warning">Smrti: {{$data->deaths}}</span>
                                                    </td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title">Najviši level</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive-md">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th style="width: 10px">#</th>
                                                    <th>Ime</th>
                                                    <th>Level</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                $counter = 1
                                                @endphp
                                                @foreach ($level as $data)
                                                <tr>
                                                    <td>{{$counter ++}}</td>
                                                    <td>{{$data->name}}</td>
                                                    <td><span class="badge bg-primary">Level: {{$data->level}}</span>
                                                    </td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
