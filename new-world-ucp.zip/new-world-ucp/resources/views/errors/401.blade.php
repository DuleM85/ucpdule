@extends('errors::minimal')

@section('title', __('Nema ovlašcenja'))
@section('code', '401')
@section('message', __('Nema ovlašcenja'))
