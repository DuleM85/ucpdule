@extends('errors::minimal')

@section('title', __('Neovlašcena radnja'))
@section('code', '403')
@section('message', __($exception->getMessage() ?: 'Neovlašcena radnja'))
