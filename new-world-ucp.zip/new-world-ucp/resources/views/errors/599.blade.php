@extends('errors::minimal')


@section('title', __('👷 Režim održavanja 👷‍♀️'))
@section('message', __('👷 Kratki radovi na održavanju 👷‍♀️'))
