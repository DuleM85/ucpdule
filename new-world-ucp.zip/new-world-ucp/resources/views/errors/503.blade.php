@extends('errors::minimal')

@section('title', __('Server nedostupan'))
@section('code', '503')
@section('message', __('Server nedostupan'))
