@extends('errors::minimal')

@section('title', __('Previše zahteva'))
@section('code', '429')
@section('message', __('Previše zahteva'))
