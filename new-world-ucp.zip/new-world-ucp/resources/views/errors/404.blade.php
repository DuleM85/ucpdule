@extends('errors::minimal')

@section('title', __('Stranica nije pronadjena'))
@section('code', '404')
@section('message', __('Stranica nije pronadjena'))
