@extends('errors::minimal')

@section('title', __('Vreme transakcije je isteklo'))
@section('code', '419')
@section('message', __('Vreme transakcije je isteklo'))
