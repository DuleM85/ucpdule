Dies ist das UCP für den Nemesus World Gamemode (RageMP/GTA 5), basierend auf Laravel / PHP 8

Hier und da gibt es natürlich noch ein paar Unschönheiten, Bugs und Unklarheiten. Diese dürfte man aber mit relativ wenig Zeit entfernen können und natürlich ist das UCP nicht zu 100% fertig gestellt!

(Euch gefällt das UCP? Dann lasst doch gerne hier bei dem Repo einen Stern da ;))

Nemesus World: https://nemesus-world.com

Test UCP: https://ucp.nemesus-world.de

Youtube: https://yt.nemesus.de

Forum: https://forum.nemesus.de

Discord: https://discord.nemesus.de

Das UCP bietet einige Features, unter anderem:

    Login/Multicharakter System
    Statseinsicht/Account Einstellungen/Accountlogs
    Onlinebanking
    Fahrzeugübersicht/verwaltung
    Fraktionsverwaltung/logs/einstellungen
    Firmen/Gruppierungsverwaltung/logs/einstellungen
    Häuser/Businessverwaltung
    Ticketsystem
    Magische Miesmuschel
    Statistiken
    Avatar Generator
    Vollständiges Adminsystem
    und vieles mehr ...
    
Ihr wollt uns unterstützen? https://ko-fi.com/nemesustv

Beachtet bitte die ToDos im Code und die Installationsanleitung auf Youtube: Coming soon

Weitere Infos gibt es auf https://nemesus.de
