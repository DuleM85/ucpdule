<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

setlocale(LC_TIME, 'de_DE', 'de_DE.UTF-8');

//FactionsController für sämtliche Fraktionsfunktionen
class GroupController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkbanned');
        $this->middleware('2fa')->except('signOut');
    }

    public function getGroups()
    {
        if (Auth::check()) {
            $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
            if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
            $mygroup = DB::table('groups_members')->where('groupsid', $group_id)->where('charid', Auth::user()->selectedcharacterintern)->first();
            if ($mygroup) {
                $characters = DB::table('groups_members')->where('groupsid', $group_id)->orderBy('rang', 'desc')->get();
                $members = DB::table('groups_members')->where('groupsid', $group_id)
                    ->count();
                $dutytime = DB::table('groups_members')->where('groupsid', $group_id)
                    ->sum('duty_time');
                $group = DB::table('groups')->where('id', $group_id)->first();
                $cars = DB::table('vehicles')->where('owner', 'group-' . $group_id)->count();
                return view('layouts.groups.groups', ['characters' => $characters, 'members' => $members, 'dutytime' => $dutytime, 'group' => $group, 'cars' => $cars, 'mygroup' => $mygroup]);
            } else {
                return redirect::to('/home')->with('error', 'Niste ni u jednoj organizaciji!');
            }
        }
    }

    public function groupCars()
    {
        if (Auth::check()) {
            $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
            if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
            $count = DB::table('vehicles')->where('owner', 'group-' . $group_id)->count();
            if (!$count || $count <= 0) return redirect::to('/groups')->with('error', 'Nema dostupnih organizacionih vozila!');
            $vehicles = DB::table('vehicles')->where('owner', 'group-' . $group_id)
                ->get();
            return view('cars', ['vehicles' => $vehicles]);
        }
    }

    public function groupLogs()
    {
        if (Auth::check()) {
            $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
            if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
            $group = DB::table('groups_members')
                ->where('groupsid', '=', $group_id)
                ->where('charid', '=', Auth::user()->selectedcharacterintern)
                ->first();
            if (!$group || $group->rang < 10) return redirect::to('/groups')->with('error', 'Nema ovlašcenja!' . $group_id);
            $logs = DB::table('logs')->where('loglabel', 'group-' . $group_id)->orderBy('timestamp', 'desc')->limit(215)->get();
            return view('layouts.groups.grouplogs', ['logs' => $logs]);
        }
    }

    public function groupMoneyLog()
    {
        if (Auth::check()) {
            $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
            if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
            $group = DB::table('groups_members')
                ->where('groupsid', '=', $group_id)
                ->where('charid', '=', Auth::user()->selectedcharacterintern)
                ->first();
            if (!$group || $group->rang < 10) return redirect::to('/groups')->with('error', 'Nema ovlašcenja!' . $group_id);
            $logs = DB::table('logs')->where('loglabel', 'groupmoney-' . $group_id)->orderBy('timestamp', 'desc')->limit(215)->get();
            return view('layouts.groups.grouplogs', ['logs' => $logs]);
        }
    }

    public function groupMoney(Request $request)
    {
        if (Auth::check()) {
            if (is_numeric($request->bookId) && is_numeric($request->payday) && $request->payday >= 0 && $request->payday <= 9999 && $request->money >= 0 && $request->money <= 999999 && is_numeric($request->money)) {
                $character = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->first();
                $findcharacter = DB::table('characters')->where('id', $request->bookId)->first();
                if (!$character || !$findcharacter) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
                if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
                if ($request->money < 0 || $request->payday < 0) return redirect::to('/home')->with('error', 'Nepravilan unos!');
                $groupleader = DB::table('groups')
                    ->where('id', '=', $group_id)
                    ->value('leader');
                $group = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', Auth::user()->selectedcharacterintern)
                    ->first();
                $group2 = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', $request->bookId)
                    ->first();
                if (!$group2) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!' . $findcharacter->name);
                if (!$group || $group->rang < 10) return redirect::to('/groups')->with('error', 'Nema ovlašcenja!');
                if (($group->rang > $group2->rang && $group->rang != $groupleader) || $group->charid == $groupleader) {
                    $online = DB::table('users')->where('id', $findcharacter->userid)->value('online');
                    if ($online == 1) return Redirect::back()->with('error', 'Igrač nije offline!');
                    $logtext = $character->name . " je platu od " . $findcharacter->name . " na " . $request->money . "$ za svaki " . $request->payday . ". Payday podesio!";
                    DB::table('logs')->insert(array('loglabel' => "group-" . $group_id, 'text' => $logtext, 'timestamp' => time()));
                    DB::table('groups_members')->where('groupsid', '=', $group_id)
                        ->where('charid', '=', $findcharacter->id)
                        ->where('groupsid', '=', $group_id)
                        ->update(['payday' => $request->money, 'payday_day' => $request->payday]);
                    return redirect::to('/groups')->with('success', 'Plate za igrača su uspešno podešene');
                } else {
                    return redirect::to('/groups')->with('error', 'Nema ovlašcenja!');
                }
            }
            return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
        }
    }

    public function groupUpRank(Request $request)
    {
        if (Auth::check()) {
            if (is_numeric($request->id)) {
                $character = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->first();
                $findcharacter = DB::table('characters')->where('id', $request->id)->first();
                if (!$character || !$findcharacter) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
                if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
                $groupleader = DB::table('groups')
                    ->where('id', '=', $group_id)
                    ->value('leader');
                $group = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', Auth::user()->selectedcharacterintern)
                    ->first();
                $group2 = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', $request->id)
                    ->first();
                if (!$group2) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!' . $findcharacter->name);
                if (!$group || $group->rang < 10) return redirect::to('/groups')->with('error', 'Nema ovlašcenja!');
                if (($group->rang > $group2->rang && $group->rang != $groupleader) || $group->charid == $groupleader) {
                    $online = DB::table('users')->where('id', $findcharacter->userid)->value('online');
                    if ($online == 1) return Redirect::back()->with('error', 'Igrač nije offline!');
                    $newrang = $group2->rang + 1;
                    if ($newrang > 12) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                    $logtext = $character->name . " je " . $findcharacter->name . " promovisao - (Novi Rang: " . $newrang . ")!";
                    DB::table('logs')->insert(array('loglabel' => "group-" . $group_id, 'text' => $logtext, 'timestamp' => time()));
                    DB::table('groups_members')->where('groupsid', '=', $group_id)
                        ->where('charid', '=', $findcharacter->id)
                        ->where('groupsid', '=', $group_id)
                        ->update(['rang' => $newrang]);
                    return redirect::to('/groups')->with('success', 'Igrač je uspešno promovisan!');
                } else {
                    return redirect::to('/groups')->with('error', 'Nema ovlašcenja!');
                }
            }
            return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
        }
    }

    public function groupDownRank(Request $request)
    {
        if (Auth::check()) {
            if (is_numeric($request->id)) {
                $character = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->first();
                $findcharacter = DB::table('characters')->where('id', $request->id)->first();
                if (!$character || !$findcharacter) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
                if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
                $groupleader = DB::table('groups')
                    ->where('id', '=', $group_id)
                    ->value('leader');
                $group = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', Auth::user()->selectedcharacterintern)
                    ->first();
                $group2 = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', $request->id)
                    ->first();
                if (!$group2) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                if (!$group || $group->rang < 10) return redirect::to('/groups')->with('error', 'Nema ovlašcenja!' . $group_id);
                if (($group->rang > $group2->rang && $group->rang != $groupleader) || $group->charid == $groupleader) {
                    $online = DB::table('users')->where('id', $findcharacter->userid)->value('online');
                    if ($online == 1) return Redirect::back()->with('error', 'Igrač nije offline!');
                    $newrang = $group2->rang - 1;
                    if ($newrang <= 0) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                    $logtext = $character->name . " je degradirao " . $findcharacter->name . " - (Novi Rang: " . $newrang . ")!";
                    DB::table('logs')->insert(array('loglabel' => "group-" . $group_id, 'text' => $logtext, 'timestamp' => time()));
                    DB::table('groups_members')->where('groupsid', '=', $group_id)
                        ->where('charid', '=', $findcharacter->id)
                        ->where('groupsid', '=', $group_id)
                        ->update(['rang' => $newrang]);
                    return redirect::to('/groups')->with('success', 'Igrač je uspešno degradiran!');
                } else {
                    return redirect::to('/groups')->with('error', 'Nema ovlašcenja!');
                }
            }
            return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
        }
    }

    public function groupKick(Request $request)
    {
        if (Auth::check()) {
            if (is_numeric($request->id)) {
                $character = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->first();
                $findcharacter = DB::table('characters')->where('id', $request->id)->first();
                if (!$character || !$findcharacter) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
                if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
                $groupleader = DB::table('groups')
                    ->where('id', '=', $group_id)
                    ->value('leader');
                $group = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', Auth::user()->selectedcharacterintern)
                    ->first();
                $group2 = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', $request->id)
                    ->first();
                if (!$group2) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                if (!$group || $group->rang < 10) return redirect::to('/groups')->with('error', 'Nema ovlašcenja!');
                if (($group->rang > $group2->rang && $group->rang != $groupleader) || $group->charid == $groupleader) {
                    $online = DB::table('users')->where('id', $findcharacter->userid)->value('online');
                    if ($online == 1) return Redirect::back()->with('error', 'Igrač nije offline!');
                    if ($group->charid == $groupleader) return Redirect::back()->with('error', 'Lider ne može biti izbačen!');
                    $logtext = $character->name . " izbacio " . $findcharacter->name . " iz organizacije!";
                    DB::table('logs')->insert(array('loglabel' => "group-" . $group_id, 'text' => $logtext, 'timestamp' => time()));
                    $text = "Organizacija ".$group->name. "napustio";
                    DB::table('timeline')->insert(array('userid' => $findcharacter->userid, 'charid' => $findcharacter->id, 'text' => $text, 'icon' => 4, 'timestamp' => time()));
                    DB::table('groups_members')->where('groupsid', '=', $group_id)
                        ->where('charid', '=', $findcharacter->id)
                        ->where('groupsid', '=', $group_id)
                        ->delete();
                    DB::table('characters')->where('mygroup', '=', $group_id)
                        ->where('id', '=', $findcharacter->id)
                        ->update(['mygroup' => -1]);
                    return redirect::to('/groups')->with('success', 'Igrač je uspešno izbačen iz organizacije!');
                } else {
                    return redirect::to('/groups')->with('error', 'Nema ovlašcenja!');
                }
            }
            return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
        }
    }

    public function groupLeader(Request $request)
    {
        if (Auth::check()) {
            if (is_numeric($request->id)) {
                $character = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->first();
                $findcharacter = DB::table('characters')->where('id', $request->id)->first();
                if (!$character || !$findcharacter) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                $group_id = DB::table('characters')->where('id', Auth::user()->selectedcharacterintern)->value('mygroup');
                if (!$group_id || $group_id <= 0) return redirect::to('/home')->with('error', 'Niste u organizaciji ili je niste aktivno izabrali!');
                $groupleader = DB::table('groups')
                    ->where('id', '=', $group_id)
                    ->value('leader');
                $group = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', Auth::user()->selectedcharacterintern)
                    ->first();
                $group2 = DB::table('groups_members')
                    ->where('groupsid', '=', $group_id)
                    ->where('charid', '=', $request->id)
                    ->first();
                if (!$group2) return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
                if (!$group || $group->charid != $groupleader) return redirect::to('/groups')->with('error', 'Nema ovlašcenja!');
                $online = DB::table('users')->where('id', $findcharacter->userid)->value('online');
                if ($online == 1) return Redirect::back()->with('error', 'Igrač nije offline!');
                if ($findcharacter->id == $groupleader) return Redirect::back()->with('error', 'Igrač je vec lider organizacije!');
                $logtext = $character->name . " postavio je " . $findcharacter->name . " za lidera organizacije!";
                DB::table('logs')->insert(array('loglabel' => "group-" . $group_id, 'text' => $logtext, 'timestamp' => time()));
                DB::table('groups_members')->where('groupsid', '=', $group_id)
                    ->where('charid', '=', $findcharacter->id)
                    ->where('groupsid', '=', $group_id)
                    ->update(['rang' => 12]);
                DB::table('groups')->where('id', '=', $group_id)
                    ->update(['leader' => $findcharacter->id]);
                return redirect::to('/groups')->with('success', 'Igrač je uspešno postavljen za lidera organizacije!');
            }
            return redirect::to('/groups')->with('error', 'Nevažeca interakcija!');
        }
    }

    public function setGroup($groupid = null)
    {
        if (Auth::check()) {
            if (!$groupid || !is_numeric($groupid) || $groupid == -1) return Redirect::back()->with('error', 'Nevažeca interakcija!');

            $check = DB::table('groups_members')->where('charid', Auth::user()
                ->selectedcharacterintern)->where('groupsid', $groupid)
                ->first();

            $character = DB::table('characters')->where('id', Auth::user()
                ->selectedcharacterintern)->first();

            if($character && $character->mygroup == $groupid) return Redirect::back()->with('error', 'Vec ste izabrali ovu organizaciju!');

            if (!$check || !$character) return Redirect::back()->with('error', 'Nevažeca interakcija!');

            if (Auth::user()->online == 1) return Redirect::back()->with('error', 'Niste offline!');

            DB::table('characters')->where('id', Auth::user()
                ->selectedcharacterintern)
                ->update(['mygroup' => $groupid]);

            return Redirect::back()->with('success', 'uspešno promena Organizacije"');
        }
    }
}
