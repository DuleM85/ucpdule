<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Exception;
use Illuminate\Support\Facades\Redirect;

setlocale(LC_TIME, 'de_DE', 'de_DE.UTF-8');

//Allgemeine Funktionen wie z.B getJobName etc
class FunctionsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkbanned');
        $this->middleware('2fa')->except('logout');
    }

    //Adminrangs
    const Kein_Admin = 0;
    const Probe_Moderator = 1;
    const Moderator = 2;
    const Supporter = 3;
    const Administrator = 4;
    const High_Administrator = 5;
    const Manager = 6;
    const Projektleiter = 7;

    public static function generatePassword(
        $passwordlength = 8,
        $numNonAlpha = 0,
        $numNumberChars = 0,
        $useCapitalLetter = false
    ) {

        $numberChars = '123456789';
        $specialChars = '!$%&=?*-:;.,+~@_';
        $secureChars = 'abcdefghjkmnpqrstuvwxyz';
        $stack = '';

        $stack = $secureChars;

        if ($useCapitalLetter == true)
            $stack .= strtoupper($secureChars);

        $count = $passwordlength - $numNonAlpha - $numNumberChars;
        $temp = str_shuffle($stack);
        $stack = substr($temp, 0, $count);

        if ($numNonAlpha > 0) {
            $temp = str_shuffle($specialChars);
            $stack .= substr($temp, 0, $numNonAlpha);
        }

        if ($numNumberChars > 0) {
            $temp = str_shuffle($numberChars);
            $stack .= substr($temp, 0, $numNumberChars);
        }

        $stack = str_shuffle($stack);

        if(strlen($stack) < 8)
        {
            return FunctionsController::generatePassword(8, 2, 2, true);
        }
        return $stack;
    }

    public static function generateCode() {;
        return mt_rand(1000, 9999);
    }

    public static function getJobName($job)
    {
        switch ($job) {
            case -1:
                return "Socijala";
            case 1:
                return "Spediter";
            case 2:
                return "Lovac";
            case 3:
                return "Busjob";
            case 4:
                return "Smecar";
            case 5:
                return "Kanalizacija";
            case 6:
                return "Taksista";
            case 7:
                return "Farmer";
            case 8:
                return "Securitas";
            default:
                return "Nijedan";
        }
    }

    public static function getAllWBBGroups($user=null)
    {
        //6: Verifiziert
        //14-16: Premium Bronze, Premium Silber, Premium Gold
        //20-21: SAPD Member, SAPD Leader
        return "6,16,15,14,21,20";
    }

    public static function updateWBBGroups($user)
    {
        try {
            if(!$user || $user->forumaccount == -1) return false;
            $groups = "6"; //Verifiziert
            $removegroups = "-1"; //Gruppen zum löschen
            //Premium
            if($user->premium > 0 && $user->premium_time > time())
            {
                if($user->premium == 1)
                {
                    $groups = $groups . ",16";
                    $removegroups = $removegroups . ",14,15";
                }
                else if($user->premium == 1)
                {
                    $groups = $groups . ",15";
                    $removegroups = $removegroups . ",14,16";
                }
                else if($user->premium == 1)
                {
                    $groups = $groups . ",14";
                    $removegroups = $removegroups . ",15,16";
                }
            }
            else
            {
                $removegroups = $removegroups . ",14,15,16";
            }
            //Fraktion
            $characters = DB::table('characters')->where('userid', $user->id)->get();
            if(!$characters) return false;
            foreach($characters as $data)
            {
                if($data->faction > 0)
                {
                    $leader = DB::table('factions')->where('id', $data->faction)->value('leader');
                    //SAPD
                    if($data->faction == 1)
                    {
                        if($data->id == $leader || $data->rang >= 10)
                        {
                            if(!str_contains($groups, ',20'))
                            {
                                $groups = $groups . ",20";
                            }
                            if(!str_contains($removegroups, ',21'))
                            {
                                $removegroups = $removegroups . ",21";
                            }
                        }
                        else
                        {
                            if(!str_contains($groups, ',21'))
                            {
                                $groups = $groups . ",21";
                            }
                            if(!str_contains($removegroups, ',20'))
                            {
                                $removegroups = $removegroups . ",20";
                            }
                        }
                    }
                }
            }
            //SAPD
            if(!str_contains($groups, ',20') && !str_contains($groups, ',21') && !str_contains($removegroups, ',20') && !str_contains($removegroups, ',21'))
            {
                $removegroups = $removegroups . ",20,21";
            }
            //Fraktionen entfernen
            $client = new \GuzzleHttp\Client();
            //ToDo: Forumconnect System einbinden
            $response1 = $client->get('HIER/forumConnect.php?id=9yeBgA33sVxRWkvXLmQv&status=removefromgroups&userid=' . $user->forumaccount . '&groupids='.$removegroups);
            $response2 = $client->get('HIER/forumConnect.php?id=9yeBgA33sVxRWkvXLmQv&status=settogroups&userid=' . $user->forumaccount . '&groupids='.$groups);
            DB::table('users')->where('id', $user->forumaccount)->update(['forumupdate' => time() + (60 * 25)]);
            return true;
        } catch (\Exception) {
            return false;
        }
    }

    public static function getAdminRangName($admin, $userid = -1)
    {
        if (!is_numeric($admin)) return "n/A";
        if ($userid != -1 && is_numeric($userid) && strlen($userid) >= 1 && strlen($userid) <= 11) {
            $rangname = DB::table('users')->where('id', $userid)->value('admin_rang');
            if ($rangname && $rangname != "n/A") {
                return $rangname;
            }
        }
        switch ($admin) {
            default:
                return "Probni Admin";
            case 1:
                return "Admin RolePlay 1";
            case 2:
                return "Admin RolePlay 2";
            case 3:
                return "Admin RolePlay 3";
            case 4:
                return "Head Admin";
            case 5:
                return "Direktor";
            case 6:
                return "Su Vlasnik";
        }
    }

    public static function getAdminStatus($id)
    {
        if (!is_numeric($id) || strlen($id) < 1 && strlen($id) > 11) return false;
        $admin = DB::table('users')->where('id', $id)->value('adminlevel');
        if ($admin && $admin > FunctionsController::Kein_Admin) {
            return true;
        }
        return false;
    }

    public static function getDSGVOClosed($id)
    {
        if (!is_numeric($id) || strlen($id) < 1 && strlen($id) > 11) return 0;
        $dsgvo_closed = DB::table('users')->where('id', $id)->value('dsgvo_closed');
        if (!$dsgvo_closed) return 0;
        return $dsgvo_closed;
    }

    public static function getGroupMembers($groupid)
    {
        if (!is_numeric($groupid) || strlen($groupid) < 1 && strlen($groupid) > 11) return 0;
        $count = DB::table('groups_members')->where('groupsid', $groupid)->count();
        return $count;
    }

    public static function getFactionMembers($factionid)
    {
        if(!$factionid)
        {
            session()->flash('error', 'Prvo kreirajte karakter!');
            session()->forget('nemesusworlducp_adminlogin');
            session()->forget('nemesusworlducp_failedadminlogin');
            session()->forget('nemesusworlducp_lasttry');
            session()->forget('google2fa');
            session()->forget('nemesusworlducp_code');
            session()->forget('nemesusworlducp_codetime');
            session()->forget('nemesusworlducp_codeid');
            session()->forget('nemesusworlducp_codeforumaccount');
            Auth::logout();
            return;
        }
        if (!is_numeric($factionid) || strlen($factionid) < 1 && strlen($factionid) > 11) return 0;
        $count = DB::table('characters')->where('faction', $factionid)->count();
        return $count;
    }

    public static function getGroupName($id)
    {
        if (!is_numeric($id) || strlen($id) < 1 && strlen($id) > 11) return "n/A";
        $name = DB::table('groups')->where('id', $id)->value('name');
        if (!$name) return 'n/A';
        return $name;
    }

    public static function getAdminLevel($id)
    {
        if (!is_numeric($id) || strlen($id) < 1 && strlen($id) > 11) return false;
        $admin = DB::table('users')->where('id', $id)->value('adminlevel');
        if ($admin) {
            return $admin;
        }
        return 0;
    }

    public static function getMiniJobName($minijob)
    {
        switch ($minijob) {
            default:
                return "Nijedan";
        }
    }

    public static function getGroupStatus($status)
    {
        switch ($status) {
            case 0:
                return "Organizacija";
            case 1:
                return "Firma";
            case 2:
                return "Politička stranka";
            default:
                return "Organizacija";
        }
    }

    public static function getAdminLogName($log)
    {
        $log = DB::table('adminlogsnames')->where('loglabel', $log)->value('name');
        if (!$log) return "n/A Log";
        return $log;
    }

    public static function getAdminLogRang($log)
    {
        $rang = DB::table('adminlogsnames')->where('loglabel', $log)->value('rang');
        if (!$rang) return 1;
        return $rang;
    }

    public static function getFraktionsName($fraktion)
    {
        if ($fraktion <= 0) return 'Nema frakcije';
        $faction = DB::table('factions')->where('id', $fraktion)->first();
        return $faction->name;
    }

    public static function getRangName($rang, $faction)
    {
        if ($rang <= 0 || $faction <= 0) return "Bez ranga";
        $rangname = 'rang' . strval($rang);
        return DB::table('factionsrangs')->where('factionid', $faction)->first()->$rangname;
    }

    public static function getRangNameGroup($rang, $group)
    {
        if ($rang <= 0 || $group <= 0) return "Bez ranga";
        $rangname = 'rang' . strval($rang);
        $rname = DB::table('groupsrangs')->where('groupsid', $group)->first()->$rangname;
        if (!$rname || $rname == null) return "Bez ranga";
        return $rname;
    }

    public static function getNameFromBank($banknumber)
    {
        if (Auth::check()) {
            $bank = DB::table('bank')->where('banknumber', $banknumber)->first();
            $name = "n/A";
            if($bank->groupid <= 0)
            {
                $charactername = DB::table('characters')->where('id', $bank->ownercharid)->value('name');
                $name = $charactername;
            }
            else
            {
                $groupname = DB::table('groups')->where('id', $bank->groupid)->value('name');
                $name = $groupname;
            }
            return $name;
        }
    }


    public static function getCharacterName($id)
    {
        if (Auth::check() && is_numeric($id) && $id != -1) {
            $character = DB::table('characters')->where('id', $id)->first();
            if (!$character || $character == null)
            {
                $name = "Nijedan";
            }
            else
            {
                $name = $character->name;
            }
            return $name;
        }
        return "Nijedan";
    }

    public static function getCharacterNameByID($id)
    {
        if (Auth::check() && is_numeric($id) && $id != -1) {
            $character = DB::table('characters')->where('id',$id)->first();
            if (!$character || $character == null)
            {
                $name = "Nijedan";
            }
            else
            {
                $name = $character->name;
            }
            return $name;
        }
        return "Nijedan";
    }

    public static function getOnlineStatus($id)
    {
        if (Auth::check() && is_numeric($id) && $id != -1) {
            $onlinestatus = DB::table('characters')->where('id',$id)->first()->online;
            return $onlinestatus;
        }
        return 0;
    }

    public static function getUserName($id, $tag = false)
    {
        if (Auth::check()) {
            $name = DB::table('users')->where('id', $id)->value('name');
            if (!$name || $name == null) {
                $name = "n/A";
            } else {
                if ($tag == true) {
                    if (Auth::user()->adminlevel > FunctionsController::Kein_Admin || session('nemesusworlducp_adminlogin')) {
                        $name = "[NW]" . $name;
                    }
                }
            }
            return $name;
        }
    }

    public static function GetDefaultKonto($id)
    {
        if (!$id || $id == -1) return "n/A";
        $konto = DB::table('characters')->where('id', $id)->first()->defaultbank;
        return $konto;
    }

    public static function getUserNameTicket($id)
    {
        if (Auth::check()) {
            $name = "Nijedan";
            if (!$id || $id == -1) return "Čeka se obrada";
            $name = DB::table('users')->where('id', $id)->value('name');
            if (!$name || $name == null)
            {
                return "Nijedan";
            }
            return $name;
        }
    }

    public static function getTicketStatus($id)
    {
        if (Auth::check()) {
            $name = "Čeka se obrada";
            if ($id == 0) $name = "Čeka se obrada";
            else if ($id == 1) $name = "U obradu";
            else if ($id == 2) $name = "Završeno";
            else if ($id == 9) $name = "Arhivirano";
            return $name;
        }
    }

    public static function countTickets($id)
    {
        $ticketcount = 0;
        if (Auth::check() && $id != null && is_numeric($id) && $id != -1) {
            if (Auth::user()->adminlevel <= FunctionsController::Kein_Admin || !session('nemesusworlducp_adminlogin')) {
                $ticketcount = DB::table('tickets as ts')->distinct()->join('ticket_user as tu', 'ts.id', '=', 'tu.ticketid')->where('ts.status', "!=", 9)->select('ts.*')->where('tu.userid', Auth::user()->id)->orderby('timestamp', 'asc')->count();
            } else {
                if(Auth::user()->adminlevel >= FunctionsController::High_Administrator)
                {
                    $ticketcount = DB::table('tickets as ts')->distinct()->join('ticket_user as tu', 'ts.id', '=', 'tu.ticketid')->where('ts.status', "!=", 9)->select('ts.*')->orderby('timestamp', 'asc')->count();
                }
                else
                {
                    $ticketcount = DB::table('tickets as ts')->distinct()->join('ticket_user as tu', 'ts.id', '=', 'tu.ticketid')->where('ts.status', "!=", 9)->select('ts.*')->where(function ($q) {
                        $q->where('tu.userid', Auth::user()->id)->orwhere('ts.admin', -1);
                    })->orderby('timestamp', 'asc')->count();
                }
            }
        }
        return $ticketcount;
    }

    public static function db_esc_like_raw($str)
    {
        $nstr = $str;
        DB::getPdo()->quote($nstr);
        $ret = str_replace(['%', '_'], ['\%', '\_'], $nstr);
        return $ret;
    }

    public static function getBankValue($banknumber)
    {
        if (Auth::check()) {
            $bankvalue = DB::table('bank')->where('banknumber', $banknumber)->sum('bankvalue');
            return $bankvalue;
        }
    }

    public static function getFaction($type)
    {
        if (Auth::check()) {
            try {
                $charid = DB::table('characters')->where('userid', Auth::user()->id)->skip(Auth::user()->selectedcharacter)->orderby('id', 'asc')->first()->id;
                $characters = DB::table('characters')->where('id', $charid)->first();
                if ($type == 'faction') {
                    $return = $characters->faction;
                } else if ($type == 'rang') {
                    $return = $characters->rang;
                }
                return $return;
            } catch (\Exception) {
                session()->flash('error', 'Prvo kreirajte karakter!');
                session()->forget('nemesusworlducp_adminlogin');
                session()->forget('nemesusworlducp_failedadminlogin');
                session()->forget('nemesusworlducp_lasttry');
                session()->forget('google2fa');
                session()->forget('nemesusworlducp_code');
                session()->forget('nemesusworlducp_codetime');
                session()->forget('nemesusworlducp_codeid');
                session()->forget('nemesusworlducp_codeforumaccount');
                Auth::logout();
                return;
            }
        }
    }

    public static function checkWartung()
    {
        if (Auth::check()) {
            $wartung = DB::table('settings')->where('id', 1)->value('wartung');
            if($wartung && $wartung == 1)
            {
                return true;
            }
            return false;
        }
    }

    public static function getGroup($type)
    {
        if (Auth::check()) {
            $charid = DB::table('characters')->where('userid', Auth::user()->id)->where('id', Auth::user()->selectedcharacterintern)->first();
            if(!$charid) return 0;
            $characters = DB::table('characters')->where('id', $charid->id)->first();
            if(!$characters) return 0;
            if ($type == 'group') {
                $return = $characters->mygroup;
            } else if ($type == 'rang') {
                $group = DB::table('groups_members')->where('charid', $charid->id)->where('groupsid', $characters->mygroup)->first();
                if(!$group) return 0;
                $return = $group->rang;
            }
            return $return;
        }
    }

    public static function getSkillName($skillevel)
    {
        if (Auth::check())
        {
            $retSkill = "Početnik";
            if(strval($skillevel) <= 1)
            {
                $retSkill = "Početnik";
            }
            else if(strval($skillevel) == 2)
            {
                $retSkill = "Iskusni";
            }
            else if(strval($skillevel) == 3)
            {
                $retSkill = "Profi";
            }
            else if(strval($skillevel) == 4)
            {
                $retSkill = "Majstor";
            }
            else if(strval($skillevel) > 4)
            {
                $retSkill = "Stručni";
            }
            return $retSkill;
        }
    }

    public static function getItemType($type)
    {
        switch ($type) {
            case 1: {
              return "Jelo";
            }
            case 2: {
              return "Pice";
            }
            case 3: {
              return "Ostalo";
            }
            case 4: {
                return "Upotrebljivi predmeti";
            }
            case 5: {
              return "Oružja";
            }
            case 6: {
              return "Municije";
            }
        }
        return "Jelo";
    }

    public static function countItemWeight($item)
    {
        $count = 0;
        if($item)
        {
            $props = explode(",", $item->props);
            if($props[0] >= 5000)
            {
                $props[0] = 0;
            }
            if($item->type != 5)
            {
                $count += $item->weight*$item->amount;
            }
            else
            {
                if($item->description == "Flaregun")
                {
                    $count += $item->weight + ($props[0] * 30);
                }
                else
                {
                    $count += $item->weight + ($props[0] * 3);
                }
            }
        }
        return $count;
    }

    public static function isAMeeleWeapon($weaponname)
    {
        switch (strtolower($weaponname)) {
            case "dolch": {
              return 1;
            }
            case "baseball-palica": {
              return 1;
            }
            case "pajser": {
              return 1;
            }
            case "lampa": {
              return 1;
            }
            case "golf-stap": {
              return 1;
            }
            case "sekira": {
              return 1;
            }
            case "mesingani-zglobovi": {
              return 1;
            }
            case "noz": {
              return 1;
            }
            case "machete": {
              return 1;
            }
            case "preklopni-noz": {
              return 1;
            }
            case "palica": {
              return 1;
            }
            case "biljarski-stap": {
              return 1;
            }
        }
        return 0;
    }

    static function replaceUmlaute($string)
    {
        $string = str_replace("ä", "ae", $string);
        $string = str_replace("ü", "ue", $string);
        $string = str_replace("ö", "oe", $string);
        $string = str_replace("Ä", "Ae", $string);
        $string = str_replace("Ü", "Ue", $string);
        $string = str_replace("Ö", "Oe", $string);
        $string = str_replace("ß", "ss", $string);
        return $string;
    }

    static function timeAgo($time_ago)
    {
        $time_ago =  strtotime($time_ago) ? strtotime($time_ago) : $time_ago;
        $time  = time() - $time_ago;

        switch ($time):
                // seconds
            case $time <= 60;
                return 'nije prošlo manje od jednog minuta';
                // minutes
            case $time >= 60 && $time < 3600;
                return (round($time / 60) == 1) ? 'jedan minut' : round($time / 60) . ' Minuti su prošli';
                // hours
            case $time >= 3600 && $time < 86400;
                return (round($time / 3600) == 1) ? 'jedan sat' : round($time / 3600) . ' Sati su prošli';
                // days
            case $time >= 86400 && $time < 604800;
                return (round($time / 86400) == 1) ? 'jedan dan' : round($time / 86400) . ' Dane su prošli';
                // weeks
            case $time >= 604800 && $time < 2600640;
                return (round($time / 604800) == 1) ? 'jedna nedelja' : round($time / 604800) . ' Nedelje su prošli';
                // months
            case $time >= 2600640 && $time < 31207680;
                return (round($time / 2600640) == 1) ? 'jedan mesec' : round($time / 2600640) . ' Meseci su prošli';
                // years
            case $time >= 31207680;
                return (round($time / 31207680) == 1) ? 'jedna godina' : round($time / 31207680) . ' Godine su prošli';

        endswitch;
    }
}
